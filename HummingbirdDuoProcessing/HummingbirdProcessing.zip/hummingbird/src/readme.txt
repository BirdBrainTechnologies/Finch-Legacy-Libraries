You can always check out the latest source of the Hummingbird package at:
http://code.google.com/p/hummingbird-robot/