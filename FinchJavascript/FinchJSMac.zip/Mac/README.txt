This code is for the Finch Robot: http://finchrobot.com

=================================================================

Running JavaScript programs to control the Finch
-----------------------------------------------

The standalone.sh/.bat script is used to run a JavaScript program that controls the Finch. 

The available methods are available in Finch.js.

An example is provided in alwaysUpHill.js. In this application, after calibrating, the Finch will always try to move up hill.

To run the example, type "runJS.sh alwaysUpHill.js" in Mac/Linux and "runJS.bat alwaysUpHill.js" in Windows.