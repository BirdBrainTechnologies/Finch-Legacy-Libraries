﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FinchCommunicator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblCmdName = New System.Windows.Forms.Label
        Me.lstCmd = New System.Windows.Forms.ListBox
        Me.cmdQuit = New System.Windows.Forms.Button
        Me.lbl4 = New System.Windows.Forms.Label
        Me.lbl3 = New System.Windows.Forms.Label
        Me.lbl2 = New System.Windows.Forms.Label
        Me.lbl1 = New System.Windows.Forms.Label
        Me.txtP1 = New System.Windows.Forms.TextBox
        Me.txtP2 = New System.Windows.Forms.TextBox
        Me.txtP3 = New System.Windows.Forms.TextBox
        Me.txtP4 = New System.Windows.Forms.TextBox
        Me.cmdSend = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblOut = New System.Windows.Forms.Label
        Me.lblOutData = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblCmdName)
        Me.GroupBox1.Controls.Add(Me.lstCmd)
        Me.GroupBox1.Controls.Add(Me.cmdQuit)
        Me.GroupBox1.Controls.Add(Me.lbl4)
        Me.GroupBox1.Controls.Add(Me.lbl3)
        Me.GroupBox1.Controls.Add(Me.lbl2)
        Me.GroupBox1.Controls.Add(Me.lbl1)
        Me.GroupBox1.Controls.Add(Me.txtP1)
        Me.GroupBox1.Controls.Add(Me.txtP2)
        Me.GroupBox1.Controls.Add(Me.txtP3)
        Me.GroupBox1.Controls.Add(Me.txtP4)
        Me.GroupBox1.Controls.Add(Me.cmdSend)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(384, 186)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Sent Bytes"
        '
        'lblCmdName
        '
        Me.lblCmdName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCmdName.Location = New System.Drawing.Point(72, 27)
        Me.lblCmdName.Name = "lblCmdName"
        Me.lblCmdName.Size = New System.Drawing.Size(198, 23)
        Me.lblCmdName.TabIndex = 21
        Me.lblCmdName.Text = "Acceleromter"
        Me.lblCmdName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lstCmd
        '
        Me.lstCmd.FormattingEnabled = True
        Me.lstCmd.Items.AddRange(New Object() {"A", "B", "I", "L", "M", "O", "R", "T", "X", "Z"})
        Me.lstCmd.Location = New System.Drawing.Point(25, 27)
        Me.lstCmd.Name = "lstCmd"
        Me.lstCmd.Size = New System.Drawing.Size(41, 134)
        Me.lstCmd.TabIndex = 20
        '
        'cmdQuit
        '
        Me.cmdQuit.Location = New System.Drawing.Point(283, 138)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.Size = New System.Drawing.Size(75, 23)
        Me.cmdQuit.TabIndex = 19
        Me.cmdQuit.Text = "Quit"
        Me.cmdQuit.UseVisualStyleBackColor = True
        '
        'lbl4
        '
        Me.lbl4.Location = New System.Drawing.Point(134, 141)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(136, 19)
        Me.lbl4.TabIndex = 18
        Me.lbl4.Text = " "
        '
        'lbl3
        '
        Me.lbl3.Location = New System.Drawing.Point(134, 115)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(136, 19)
        Me.lbl3.TabIndex = 17
        Me.lbl3.Text = " "
        '
        'lbl2
        '
        Me.lbl2.Location = New System.Drawing.Point(134, 89)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(136, 19)
        Me.lbl2.TabIndex = 16
        '
        'lbl1
        '
        Me.lbl1.Location = New System.Drawing.Point(134, 63)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(136, 19)
        Me.lbl1.TabIndex = 15
        Me.lbl1.Text = " "
        '
        'txtP1
        '
        Me.txtP1.Enabled = False
        Me.txtP1.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP1.Location = New System.Drawing.Point(72, 63)
        Me.txtP1.Name = "txtP1"
        Me.txtP1.Size = New System.Drawing.Size(50, 20)
        Me.txtP1.TabIndex = 13
        Me.txtP1.Text = "0"
        Me.txtP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtP2
        '
        Me.txtP2.Enabled = False
        Me.txtP2.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP2.Location = New System.Drawing.Point(72, 89)
        Me.txtP2.Name = "txtP2"
        Me.txtP2.Size = New System.Drawing.Size(50, 20)
        Me.txtP2.TabIndex = 12
        Me.txtP2.Text = "0"
        Me.txtP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtP3
        '
        Me.txtP3.Enabled = False
        Me.txtP3.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP3.Location = New System.Drawing.Point(72, 115)
        Me.txtP3.Name = "txtP3"
        Me.txtP3.Size = New System.Drawing.Size(50, 20)
        Me.txtP3.TabIndex = 11
        Me.txtP3.Text = "0"
        Me.txtP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtP4
        '
        Me.txtP4.Enabled = False
        Me.txtP4.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP4.Location = New System.Drawing.Point(72, 141)
        Me.txtP4.Name = "txtP4"
        Me.txtP4.Size = New System.Drawing.Size(50, 20)
        Me.txtP4.TabIndex = 10
        Me.txtP4.Text = "0"
        Me.txtP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmdSend
        '
        Me.cmdSend.Location = New System.Drawing.Point(283, 107)
        Me.cmdSend.Name = "cmdSend"
        Me.cmdSend.Size = New System.Drawing.Size(75, 23)
        Me.cmdSend.TabIndex = 8
        Me.cmdSend.Text = "Send"
        Me.cmdSend.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.lblOut)
        Me.GroupBox2.Controls.Add(Me.lblOutData)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 204)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(384, 93)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Received Bytes"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(305, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 23)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Counter"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblOut
        '
        Me.lblOut.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOut.Location = New System.Drawing.Point(36, 52)
        Me.lblOut.Name = "lblOut"
        Me.lblOut.Size = New System.Drawing.Size(263, 23)
        Me.lblOut.TabIndex = 10
        Me.lblOut.Text = "        Left Right"
        Me.lblOut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblOutData
        '
        Me.lblOutData.BackColor = System.Drawing.SystemColors.Window
        Me.lblOutData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutData.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutData.Location = New System.Drawing.Point(36, 32)
        Me.lblOutData.Name = "lblOutData"
        Me.lblOutData.Size = New System.Drawing.Size(291, 20)
        Me.lblOutData.TabIndex = 9
        Me.lblOutData.Text = "  000  000  000  000  000  000  000  000  000"
        Me.lblOutData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FinchCommunicator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(410, 310)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FinchCommunicator"
        Me.Text = "Finch Communicator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdSend As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtP1 As System.Windows.Forms.TextBox
    Friend WithEvents txtP2 As System.Windows.Forms.TextBox
    Friend WithEvents txtP3 As System.Windows.Forms.TextBox
    Friend WithEvents txtP4 As System.Windows.Forms.TextBox
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lblOutData As System.Windows.Forms.Label
    Friend WithEvents cmdQuit As System.Windows.Forms.Button
    Friend WithEvents lstCmd As System.Windows.Forms.ListBox
    Friend WithEvents lblOut As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblCmdName As System.Windows.Forms.Label
End Class
