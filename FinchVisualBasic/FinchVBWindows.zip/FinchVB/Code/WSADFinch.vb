﻿Public Class WSADFinch

    Dim myFinch As Finch
    Dim speed As Integer = 128

    ' W = 87
    ' S = 83
    ' A = 65
    ' D = 68
    ' UP = 38
    ' DOWN = 40
    ' LEFT = 37
    ' RIGHT = 39

    Const W As Integer = 87
    Const S As Integer = 83
    Const A As Integer = 65
    Const D As Integer = 68

    Const SHIFT As Integer = 16

    Const RED As Integer = 56
    Const GREEN As Integer = 57
    Const BLUE As Integer = 48

    Dim w_dwn, a_dwn, s_dwn, d_dwn As Boolean
    Dim r, g, b As Integer
    Dim boost As Boolean

    Private Sub WSADFinch_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        myFinch.quit()
    End Sub

    Private Sub WSADFinch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyValue
            Case W
                w_dwn = True
            Case S
                s_dwn = True
            Case A
                a_dwn = True
            Case D
                d_dwn = True
            Case RED
                r = 1
                setLED()
                beep(2000)
            Case GREEN
                g = 1
                setLED()
                beep(4000)
            Case BLUE
                b = 1
                setLED()
                beep(8000)
            Case SHIFT
                boost = True
        End Select
    End Sub

    Private Sub WSADFinch_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        Select Case e.KeyValue
            Case W
                w_dwn = False
            Case S
                s_dwn = False
            Case A
                a_dwn = False
            Case D
                d_dwn = False
            Case RED
                r = 0
            Case GREEN
                g = 0
            Case BLUE
                b = 0
            Case SHIFT
                boost = False
        End Select

        setLED()
    End Sub

    Private Sub WSADFinch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        myFinch = New Finch()
        myFinch.setLED(255, 0, 0)
    End Sub

    Private Sub tmrMove_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrMove.Tick
        Dim vector As Integer() = {0, 0}

        ' Forward Backward movement

        If w_dwn And Not s_dwn Then ' Forward
            vector = New Integer() {speed, speed}
        ElseIf s_dwn And Not w_dwn Then ' Backward
            vector = New Integer() {-speed, -speed}
        End If

        ' Left Right movement

        If a_dwn And Not d_dwn Then ' Turn Left
            If w_dwn = s_dwn Then
                vector = New Integer() {-speed, speed}
            Else
                vector = New Integer() {vector(0) - speed, vector(1) + speed}
            End If
        ElseIf d_dwn And Not a_dwn Then ' Turn right
            If w_dwn = s_dwn Then
                vector = New Integer() {speed, -speed}
            Else
                vector = New Integer() {vector(0) + speed, vector(1) - speed}
            End If
        End If

        If boost Then
            vector(0) = vector(0) * 2
            vector(1) = vector(1) * 2
        End If

        myFinch.setWheelVelocities(vector(0), vector(1))
    End Sub

    Public Sub setLED()
        myFinch.setLED(255 * r, 255 * g, 255 * b)
    End Sub

    Public Sub beep(ByVal freq As Integer)
        For i As Integer = freq To freq / 2 Step -((freq - (freq / 2)) / 5)
            myFinch.startBuzz(i)
        Next
        myFinch.stopBuzz()
    End Sub

End Class