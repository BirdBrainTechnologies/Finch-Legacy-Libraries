﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FinchControlPanel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblColor = New System.Windows.Forms.Label
        Me.txtBlue = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.tbrBlue = New System.Windows.Forms.TrackBar
        Me.txtGreen = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.tbrGreen = New System.Windows.Forms.TrackBar
        Me.txtRed = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.tbrRed = New System.Windows.Forms.TrackBar
        Me.cmdLED = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtDuration = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.tbrFrequency = New System.Windows.Forms.TrackBar
        Me.txtFrequency = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.tbrDuration = New System.Windows.Forms.TrackBar
        Me.cmdBuzz = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.tbrRightMotor = New System.Windows.Forms.TrackBar
        Me.tbrLeftMotor = New System.Windows.Forms.TrackBar
        Me.txtLeftMotor = New System.Windows.Forms.TextBox
        Me.txtRightMotor = New System.Windows.Forms.TextBox
        Me.chkMove = New System.Windows.Forms.CheckBox
        Me.chkSyncMotors = New System.Windows.Forms.CheckBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.tbrRightLight = New System.Windows.Forms.TrackBar
        Me.tbrLeftLight = New System.Windows.Forms.TrackBar
        Me.lblZ = New System.Windows.Forms.Label
        Me.lblY = New System.Windows.Forms.Label
        Me.lblX = New System.Windows.Forms.Label
        Me.tbrZ = New System.Windows.Forms.TrackBar
        Me.tbrY = New System.Windows.Forms.TrackBar
        Me.tbrX = New System.Windows.Forms.TrackBar
        Me.lblRightObs = New System.Windows.Forms.Label
        Me.lblLeftObs = New System.Windows.Forms.Label
        Me.chkObs = New System.Windows.Forms.CheckBox
        Me.chkTemp = New System.Windows.Forms.CheckBox
        Me.chkAcc = New System.Windows.Forms.CheckBox
        Me.chkLight = New System.Windows.Forms.CheckBox
        Me.chkRead = New System.Windows.Forms.CheckBox
        Me.cmdClear = New System.Windows.Forms.Button
        Me.tmrRead = New System.Windows.Forms.Timer(Me.components)
        Me.tbrTemp = New System.Windows.Forms.TrackBar
        Me.lblRlight = New System.Windows.Forms.Label
        Me.lblLlight = New System.Windows.Forms.Label
        Me.lblTemp = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        CType(Me.tbrBlue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrGreen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrRed, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.tbrFrequency, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrDuration, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.tbrRightMotor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrLeftMotor, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.tbrRightLight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrLeftLight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrZ, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrTemp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblColor)
        Me.GroupBox1.Controls.Add(Me.txtBlue)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.tbrBlue)
        Me.GroupBox1.Controls.Add(Me.txtGreen)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.tbrGreen)
        Me.GroupBox1.Controls.Add(Me.txtRed)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.tbrRed)
        Me.GroupBox1.Controls.Add(Me.cmdLED)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 364)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(529, 102)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "LED"
        '
        'lblColor
        '
        Me.lblColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblColor.Location = New System.Drawing.Point(6, 45)
        Me.lblColor.Name = "lblColor"
        Me.lblColor.Size = New System.Drawing.Size(75, 40)
        Me.lblColor.TabIndex = 10
        '
        'txtBlue
        '
        Me.txtBlue.Location = New System.Drawing.Point(468, 65)
        Me.txtBlue.Name = "txtBlue"
        Me.txtBlue.Size = New System.Drawing.Size(49, 20)
        Me.txtBlue.TabIndex = 9
        Me.txtBlue.Text = "0"
        Me.txtBlue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(87, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 23)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Blue"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbrBlue
        '
        Me.tbrBlue.AutoSize = False
        Me.tbrBlue.LargeChange = 32
        Me.tbrBlue.Location = New System.Drawing.Point(135, 65)
        Me.tbrBlue.Maximum = 255
        Me.tbrBlue.Name = "tbrBlue"
        Me.tbrBlue.Size = New System.Drawing.Size(327, 23)
        Me.tbrBlue.TabIndex = 7
        Me.tbrBlue.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'txtGreen
        '
        Me.txtGreen.Location = New System.Drawing.Point(468, 42)
        Me.txtGreen.Name = "txtGreen"
        Me.txtGreen.Size = New System.Drawing.Size(49, 20)
        Me.txtGreen.TabIndex = 6
        Me.txtGreen.Text = "0"
        Me.txtGreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(87, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 23)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Green"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbrGreen
        '
        Me.tbrGreen.AutoSize = False
        Me.tbrGreen.LargeChange = 32
        Me.tbrGreen.Location = New System.Drawing.Point(135, 42)
        Me.tbrGreen.Maximum = 255
        Me.tbrGreen.Name = "tbrGreen"
        Me.tbrGreen.Size = New System.Drawing.Size(327, 23)
        Me.tbrGreen.TabIndex = 4
        Me.tbrGreen.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'txtRed
        '
        Me.txtRed.Location = New System.Drawing.Point(468, 19)
        Me.txtRed.Name = "txtRed"
        Me.txtRed.Size = New System.Drawing.Size(49, 20)
        Me.txtRed.TabIndex = 3
        Me.txtRed.Text = "0"
        Me.txtRed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(87, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 23)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Red"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbrRed
        '
        Me.tbrRed.AutoSize = False
        Me.tbrRed.LargeChange = 32
        Me.tbrRed.Location = New System.Drawing.Point(135, 19)
        Me.tbrRed.Maximum = 255
        Me.tbrRed.Name = "tbrRed"
        Me.tbrRed.Size = New System.Drawing.Size(327, 23)
        Me.tbrRed.TabIndex = 1
        Me.tbrRed.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'cmdLED
        '
        Me.cmdLED.Location = New System.Drawing.Point(6, 19)
        Me.cmdLED.Name = "cmdLED"
        Me.cmdLED.Size = New System.Drawing.Size(75, 23)
        Me.cmdLED.TabIndex = 0
        Me.cmdLED.Text = "Set LED"
        Me.cmdLED.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtDuration)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.tbrFrequency)
        Me.GroupBox2.Controls.Add(Me.txtFrequency)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.tbrDuration)
        Me.GroupBox2.Controls.Add(Me.cmdBuzz)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 288)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(529, 70)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Buzzer"
        '
        'txtDuration
        '
        Me.txtDuration.Location = New System.Drawing.Point(468, 16)
        Me.txtDuration.Name = "txtDuration"
        Me.txtDuration.Size = New System.Drawing.Size(49, 20)
        Me.txtDuration.TabIndex = 9
        Me.txtDuration.Text = "0"
        Me.txtDuration.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(87, 39)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 23)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Frequency (Hz)"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbrFrequency
        '
        Me.tbrFrequency.AutoSize = False
        Me.tbrFrequency.LargeChange = 32
        Me.tbrFrequency.Location = New System.Drawing.Point(179, 39)
        Me.tbrFrequency.Maximum = 20000
        Me.tbrFrequency.Name = "tbrFrequency"
        Me.tbrFrequency.Size = New System.Drawing.Size(283, 23)
        Me.tbrFrequency.TabIndex = 7
        Me.tbrFrequency.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'txtFrequency
        '
        Me.txtFrequency.Location = New System.Drawing.Point(468, 42)
        Me.txtFrequency.Name = "txtFrequency"
        Me.txtFrequency.Size = New System.Drawing.Size(49, 20)
        Me.txtFrequency.TabIndex = 6
        Me.txtFrequency.Text = "0"
        Me.txtFrequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(87, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 23)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Duration (ms)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbrDuration
        '
        Me.tbrDuration.AutoSize = False
        Me.tbrDuration.LargeChange = 32
        Me.tbrDuration.Location = New System.Drawing.Point(179, 16)
        Me.tbrDuration.Maximum = 10000
        Me.tbrDuration.Name = "tbrDuration"
        Me.tbrDuration.Size = New System.Drawing.Size(283, 23)
        Me.tbrDuration.TabIndex = 4
        Me.tbrDuration.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'cmdBuzz
        '
        Me.cmdBuzz.Location = New System.Drawing.Point(6, 19)
        Me.cmdBuzz.Name = "cmdBuzz"
        Me.cmdBuzz.Size = New System.Drawing.Size(75, 23)
        Me.cmdBuzz.TabIndex = 0
        Me.cmdBuzz.Text = "Buzz"
        Me.cmdBuzz.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.tbrRightMotor)
        Me.GroupBox3.Controls.Add(Me.tbrLeftMotor)
        Me.GroupBox3.Controls.Add(Me.txtLeftMotor)
        Me.GroupBox3.Controls.Add(Me.txtRightMotor)
        Me.GroupBox3.Controls.Add(Me.chkMove)
        Me.GroupBox3.Controls.Add(Me.chkSyncMotors)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(115, 270)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Motors"
        '
        'tbrRightMotor
        '
        Me.tbrRightMotor.AutoSize = False
        Me.tbrRightMotor.LargeChange = 32
        Me.tbrRightMotor.Location = New System.Drawing.Point(61, 97)
        Me.tbrRightMotor.Maximum = 255
        Me.tbrRightMotor.Minimum = -255
        Me.tbrRightMotor.Name = "tbrRightMotor"
        Me.tbrRightMotor.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrRightMotor.Size = New System.Drawing.Size(49, 167)
        Me.tbrRightMotor.TabIndex = 13
        Me.tbrRightMotor.TickFrequency = 64
        Me.tbrRightMotor.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        '
        'tbrLeftMotor
        '
        Me.tbrLeftMotor.AutoSize = False
        Me.tbrLeftMotor.LargeChange = 32
        Me.tbrLeftMotor.Location = New System.Drawing.Point(21, 97)
        Me.tbrLeftMotor.Maximum = 255
        Me.tbrLeftMotor.Minimum = -255
        Me.tbrLeftMotor.Name = "tbrLeftMotor"
        Me.tbrLeftMotor.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrLeftMotor.Size = New System.Drawing.Size(34, 167)
        Me.tbrLeftMotor.TabIndex = 12
        Me.tbrLeftMotor.TickFrequency = 64
        '
        'txtLeftMotor
        '
        Me.txtLeftMotor.Location = New System.Drawing.Point(6, 71)
        Me.txtLeftMotor.Name = "txtLeftMotor"
        Me.txtLeftMotor.Size = New System.Drawing.Size(49, 20)
        Me.txtLeftMotor.TabIndex = 11
        Me.txtLeftMotor.Text = "0"
        Me.txtLeftMotor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtRightMotor
        '
        Me.txtRightMotor.Location = New System.Drawing.Point(61, 71)
        Me.txtRightMotor.Name = "txtRightMotor"
        Me.txtRightMotor.Size = New System.Drawing.Size(49, 20)
        Me.txtRightMotor.TabIndex = 10
        Me.txtRightMotor.Text = "0"
        Me.txtRightMotor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkMove
        '
        Me.chkMove.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkMove.Location = New System.Drawing.Point(6, 19)
        Me.chkMove.Name = "chkMove"
        Me.chkMove.Size = New System.Drawing.Size(104, 24)
        Me.chkMove.TabIndex = 2
        Me.chkMove.Text = "Move"
        Me.chkMove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chkMove.UseVisualStyleBackColor = True
        '
        'chkSyncMotors
        '
        Me.chkSyncMotors.AutoSize = True
        Me.chkSyncMotors.Location = New System.Drawing.Point(6, 48)
        Me.chkSyncMotors.Name = "chkSyncMotors"
        Me.chkSyncMotors.Size = New System.Drawing.Size(85, 17)
        Me.chkSyncMotors.TabIndex = 1
        Me.chkSyncMotors.Text = "Sync Motors"
        Me.chkSyncMotors.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.lblTemp)
        Me.GroupBox4.Controls.Add(Me.lblRlight)
        Me.GroupBox4.Controls.Add(Me.lblLlight)
        Me.GroupBox4.Controls.Add(Me.tbrTemp)
        Me.GroupBox4.Controls.Add(Me.tbrRightLight)
        Me.GroupBox4.Controls.Add(Me.tbrLeftLight)
        Me.GroupBox4.Controls.Add(Me.lblZ)
        Me.GroupBox4.Controls.Add(Me.lblY)
        Me.GroupBox4.Controls.Add(Me.lblX)
        Me.GroupBox4.Controls.Add(Me.tbrZ)
        Me.GroupBox4.Controls.Add(Me.tbrY)
        Me.GroupBox4.Controls.Add(Me.tbrX)
        Me.GroupBox4.Controls.Add(Me.lblRightObs)
        Me.GroupBox4.Controls.Add(Me.lblLeftObs)
        Me.GroupBox4.Controls.Add(Me.chkObs)
        Me.GroupBox4.Controls.Add(Me.chkTemp)
        Me.GroupBox4.Controls.Add(Me.chkAcc)
        Me.GroupBox4.Controls.Add(Me.chkLight)
        Me.GroupBox4.Controls.Add(Me.chkRead)
        Me.GroupBox4.Controls.Add(Me.cmdClear)
        Me.GroupBox4.Location = New System.Drawing.Point(133, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(408, 270)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Sensors"
        '
        'tbrRightLight
        '
        Me.tbrRightLight.Enabled = False
        Me.tbrRightLight.Location = New System.Drawing.Point(58, 73)
        Me.tbrRightLight.Maximum = 255
        Me.tbrRightLight.Name = "tbrRightLight"
        Me.tbrRightLight.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrRightLight.Size = New System.Drawing.Size(45, 151)
        Me.tbrRightLight.TabIndex = 16
        Me.tbrRightLight.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'tbrLeftLight
        '
        Me.tbrLeftLight.Enabled = False
        Me.tbrLeftLight.Location = New System.Drawing.Point(10, 73)
        Me.tbrLeftLight.Maximum = 255
        Me.tbrLeftLight.Name = "tbrLeftLight"
        Me.tbrLeftLight.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrLeftLight.Size = New System.Drawing.Size(45, 151)
        Me.tbrLeftLight.TabIndex = 15
        Me.tbrLeftLight.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'lblZ
        '
        Me.lblZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblZ.Location = New System.Drawing.Point(211, 227)
        Me.lblZ.Name = "lblZ"
        Me.lblZ.Size = New System.Drawing.Size(45, 20)
        Me.lblZ.TabIndex = 14
        Me.lblZ.Text = "0.00"
        Me.lblZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblY
        '
        Me.lblY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblY.Location = New System.Drawing.Point(160, 227)
        Me.lblY.Name = "lblY"
        Me.lblY.Size = New System.Drawing.Size(45, 20)
        Me.lblY.TabIndex = 13
        Me.lblY.Text = "0.00"
        Me.lblY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblX
        '
        Me.lblX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblX.Location = New System.Drawing.Point(109, 227)
        Me.lblX.Name = "lblX"
        Me.lblX.Size = New System.Drawing.Size(45, 20)
        Me.lblX.TabIndex = 12
        Me.lblX.Text = "0.00"
        Me.lblX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tbrZ
        '
        Me.tbrZ.AutoSize = False
        Me.tbrZ.Enabled = False
        Me.tbrZ.Location = New System.Drawing.Point(211, 73)
        Me.tbrZ.Maximum = 15
        Me.tbrZ.Minimum = -15
        Me.tbrZ.Name = "tbrZ"
        Me.tbrZ.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrZ.Size = New System.Drawing.Size(32, 151)
        Me.tbrZ.TabIndex = 11
        Me.tbrZ.TickFrequency = 5
        '
        'tbrY
        '
        Me.tbrY.AutoSize = False
        Me.tbrY.Enabled = False
        Me.tbrY.Location = New System.Drawing.Point(160, 73)
        Me.tbrY.Maximum = 15
        Me.tbrY.Minimum = -15
        Me.tbrY.Name = "tbrY"
        Me.tbrY.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrY.Size = New System.Drawing.Size(36, 151)
        Me.tbrY.TabIndex = 10
        Me.tbrY.TickFrequency = 5
        '
        'tbrX
        '
        Me.tbrX.AutoSize = False
        Me.tbrX.Enabled = False
        Me.tbrX.Location = New System.Drawing.Point(109, 73)
        Me.tbrX.Maximum = 15
        Me.tbrX.Minimum = -15
        Me.tbrX.Name = "tbrX"
        Me.tbrX.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrX.Size = New System.Drawing.Size(30, 151)
        Me.tbrX.TabIndex = 9
        Me.tbrX.TickFrequency = 5
        '
        'lblRightObs
        '
        Me.lblRightObs.BackColor = System.Drawing.Color.White
        Me.lblRightObs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRightObs.Location = New System.Drawing.Point(365, 73)
        Me.lblRightObs.Name = "lblRightObs"
        Me.lblRightObs.Size = New System.Drawing.Size(26, 23)
        Me.lblRightObs.TabIndex = 8
        '
        'lblLeftObs
        '
        Me.lblLeftObs.BackColor = System.Drawing.Color.White
        Me.lblLeftObs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLeftObs.Location = New System.Drawing.Point(323, 73)
        Me.lblLeftObs.Name = "lblLeftObs"
        Me.lblLeftObs.Size = New System.Drawing.Size(26, 23)
        Me.lblLeftObs.TabIndex = 7
        '
        'chkObs
        '
        Me.chkObs.AutoSize = True
        Me.chkObs.Location = New System.Drawing.Point(323, 48)
        Me.chkObs.Name = "chkObs"
        Me.chkObs.Size = New System.Drawing.Size(73, 17)
        Me.chkObs.TabIndex = 6
        Me.chkObs.Text = "Obstacles"
        Me.chkObs.UseVisualStyleBackColor = True
        '
        'chkTemp
        '
        Me.chkTemp.AutoSize = True
        Me.chkTemp.Location = New System.Drawing.Point(231, 48)
        Me.chkTemp.Name = "chkTemp"
        Me.chkTemp.Size = New System.Drawing.Size(86, 17)
        Me.chkTemp.TabIndex = 5
        Me.chkTemp.Text = "Temperature"
        Me.chkTemp.UseVisualStyleBackColor = True
        '
        'chkAcc
        '
        Me.chkAcc.AutoSize = True
        Me.chkAcc.Location = New System.Drawing.Point(124, 48)
        Me.chkAcc.Name = "chkAcc"
        Me.chkAcc.Size = New System.Drawing.Size(85, 17)
        Me.chkAcc.TabIndex = 4
        Me.chkAcc.Text = "Acceleration"
        Me.chkAcc.UseVisualStyleBackColor = True
        '
        'chkLight
        '
        Me.chkLight.AutoSize = True
        Me.chkLight.Location = New System.Drawing.Point(26, 49)
        Me.chkLight.Name = "chkLight"
        Me.chkLight.Size = New System.Drawing.Size(49, 17)
        Me.chkLight.TabIndex = 3
        Me.chkLight.Text = "Light"
        Me.chkLight.UseVisualStyleBackColor = True
        '
        'chkRead
        '
        Me.chkRead.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkRead.Location = New System.Drawing.Point(6, 19)
        Me.chkRead.Name = "chkRead"
        Me.chkRead.Size = New System.Drawing.Size(104, 24)
        Me.chkRead.TabIndex = 2
        Me.chkRead.Text = "Read Sensors"
        Me.chkRead.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chkRead.UseVisualStyleBackColor = True
        '
        'cmdClear
        '
        Me.cmdClear.Location = New System.Drawing.Point(116, 19)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.Size = New System.Drawing.Size(104, 23)
        Me.cmdClear.TabIndex = 1
        Me.cmdClear.Text = "Clear Data"
        Me.cmdClear.UseVisualStyleBackColor = True
        '
        'tmrRead
        '
        '
        'tbrTemp
        '
        Me.tbrTemp.Enabled = False
        Me.tbrTemp.Location = New System.Drawing.Point(262, 73)
        Me.tbrTemp.Maximum = 40
        Me.tbrTemp.Name = "tbrTemp"
        Me.tbrTemp.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrTemp.Size = New System.Drawing.Size(45, 151)
        Me.tbrTemp.TabIndex = 17
        Me.tbrTemp.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'lblRlight
        '
        Me.lblRlight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRlight.Location = New System.Drawing.Point(58, 227)
        Me.lblRlight.Name = "lblRlight"
        Me.lblRlight.Size = New System.Drawing.Size(45, 20)
        Me.lblRlight.TabIndex = 15
        Me.lblRlight.Text = "0.00"
        Me.lblRlight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLlight
        '
        Me.lblLlight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLlight.Location = New System.Drawing.Point(7, 227)
        Me.lblLlight.Name = "lblLlight"
        Me.lblLlight.Size = New System.Drawing.Size(45, 20)
        Me.lblLlight.TabIndex = 14
        Me.lblLlight.Text = "0.00"
        Me.lblLlight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTemp
        '
        Me.lblTemp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTemp.Location = New System.Drawing.Point(262, 227)
        Me.lblTemp.Name = "lblTemp"
        Me.lblTemp.Size = New System.Drawing.Size(45, 20)
        Me.lblTemp.TabIndex = 15
        Me.lblTemp.Text = "0.00"
        Me.lblTemp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FinchControlPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(558, 480)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FinchControlPanel"
        Me.Text = "FinchControlPanel"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.tbrBlue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrGreen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrRed, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.tbrFrequency, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrDuration, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.tbrRightMotor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrLeftMotor, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.tbrRightLight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrLeftLight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrZ, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrTemp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents tbrRed As System.Windows.Forms.TrackBar
    Friend WithEvents cmdLED As System.Windows.Forms.Button
    Friend WithEvents cmdBuzz As System.Windows.Forms.Button
    Friend WithEvents cmdClear As System.Windows.Forms.Button
    Friend WithEvents lblColor As System.Windows.Forms.Label
    Friend WithEvents txtBlue As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbrBlue As System.Windows.Forms.TrackBar
    Friend WithEvents txtGreen As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbrGreen As System.Windows.Forms.TrackBar
    Friend WithEvents txtRed As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtDuration As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tbrFrequency As System.Windows.Forms.TrackBar
    Friend WithEvents txtFrequency As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbrDuration As System.Windows.Forms.TrackBar
    Friend WithEvents chkSyncMotors As System.Windows.Forms.CheckBox
    Friend WithEvents tbrRightMotor As System.Windows.Forms.TrackBar
    Friend WithEvents tbrLeftMotor As System.Windows.Forms.TrackBar
    Friend WithEvents txtLeftMotor As System.Windows.Forms.TextBox
    Friend WithEvents txtRightMotor As System.Windows.Forms.TextBox
    Friend WithEvents chkMove As System.Windows.Forms.CheckBox
    Friend WithEvents chkRead As System.Windows.Forms.CheckBox
    Friend WithEvents chkObs As System.Windows.Forms.CheckBox
    Friend WithEvents chkTemp As System.Windows.Forms.CheckBox
    Friend WithEvents chkAcc As System.Windows.Forms.CheckBox
    Friend WithEvents chkLight As System.Windows.Forms.CheckBox
    Friend WithEvents lblRightObs As System.Windows.Forms.Label
    Friend WithEvents lblLeftObs As System.Windows.Forms.Label
    Friend WithEvents tmrRead As System.Windows.Forms.Timer
    Friend WithEvents tbrZ As System.Windows.Forms.TrackBar
    Friend WithEvents tbrY As System.Windows.Forms.TrackBar
    Friend WithEvents tbrX As System.Windows.Forms.TrackBar
    Friend WithEvents lblZ As System.Windows.Forms.Label
    Friend WithEvents lblY As System.Windows.Forms.Label
    Friend WithEvents lblX As System.Windows.Forms.Label
    Friend WithEvents tbrLeftLight As System.Windows.Forms.TrackBar
    Friend WithEvents tbrRightLight As System.Windows.Forms.TrackBar
    Friend WithEvents tbrTemp As System.Windows.Forms.TrackBar
    Friend WithEvents lblTemp As System.Windows.Forms.Label
    Friend WithEvents lblRlight As System.Windows.Forms.Label
    Friend WithEvents lblLlight As System.Windows.Forms.Label
End Class
