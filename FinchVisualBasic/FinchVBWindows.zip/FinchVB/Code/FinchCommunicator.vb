﻿Imports System.Windows.Forms

Public Class FinchCommunicator
    Dim myFinch As Finch

    Private Sub cmdSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSend.Click
        Dim writeBuffer(8) As Byte
        Dim readBuffer(8) As Byte

        lblOutData.Text = ""

        Try
            writeBuffer(0) = 0
            writeBuffer(1) = Convert.ToByte(Asc(lstCmd.Text))
            writeBuffer(2) = getByte(txtP1)
            writeBuffer(3) = getByte(txtP2)
            writeBuffer(4) = getByte(txtP3)
            writeBuffer(5) = getByte(txtP4)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        readBuffer = myFinch.sendData(writeBuffer, True)

        For i As Integer = 0 To UBound(readBuffer)
            lblOutData.Text = lblOutData.Text & "  " & Format(readBuffer(i), "000")
        Next
    End Sub

    Function getByte(ByRef txt As TextBox) As Integer
        Dim b As Byte = 0

        If txt.Text = "" Then
            txt.Text = "0"
        End If

        Try
            b = Convert.ToByte(txt.Text)
        Catch ex As Exception
            Throw ex
        End Try

        Return b
    End Function

    Private Sub FinchCommunicator_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        myFinch = New Finch()
        If Not myFinch.isConnected Then
            Me.Close()
        End If
        lstCmd.SelectedIndex = 0
    End Sub

    Private Sub lstCmd_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstCmd.SelectedIndexChanged

        Select Case lstCmd.Text
            Case "A"
                lblCmdName.Text = "Accelerometer"
                lbl1.Text = ""
                lbl2.Text = ""
                lbl3.Text = ""
                lbl4.Text = ""
                txtP1.Enabled = False
                txtP2.Enabled = False
                txtP3.Enabled = False
                txtP4.Enabled = False
                lblOut.Text = "            [X]  [Y]  [Z] Shake/Tap"
            Case "B"
                lblCmdName.Text = "Buzzer"
                lbl1.Text = "Duration High Byte"
                lbl2.Text = "Duration Low Byte"
                lbl3.Text = "Frequency High Byte"
                lbl4.Text = "Frequency Low Byte"
                txtP1.Enabled = True
                txtP2.Enabled = True
                txtP3.Enabled = True
                txtP4.Enabled = True
                lblOut.Text = ""
            Case "I"
                lblCmdName.Text = "IR Sensors"
                lbl1.Text = ""
                lbl2.Text = ""
                lbl3.Text = ""
                lbl4.Text = ""
                txtP1.Enabled = False
                txtP2.Enabled = False
                txtP3.Enabled = False
                txtP4.Enabled = False
                lblOut.Text = "       Left Right"
            Case "L"
                lblCmdName.Text = "Light Sensors"
                lbl1.Text = ""
                lbl2.Text = ""
                lbl3.Text = ""
                lbl4.Text = ""
                txtP1.Enabled = False
                txtP2.Enabled = False
                txtP3.Enabled = False
                txtP4.Enabled = False
                lblOut.Text = ""
            Case "M"
                lblCmdName.Text = "Motors"
                lbl1.Text = "Left Direction"
                lbl2.Text = "Left Speed"
                lbl3.Text = "Right Direction"
                lbl4.Text = "Right Speed"
                txtP1.Enabled = True
                txtP2.Enabled = True
                txtP3.Enabled = True
                txtP4.Enabled = True
                lblOut.Text = ""
            Case "O"
                lblCmdName.Text = "LED Orb"
                lbl1.Text = "Red Intensity"
                lbl2.Text = "Green Intensity"
                lbl3.Text = "Blue Intensity"
                lbl4.Text = ""
                txtP1.Enabled = True
                txtP2.Enabled = True
                txtP3.Enabled = True
                txtP4.Enabled = False
                lblOut.Text = ""
            Case "R"
                lblCmdName.Text = "Stop"
                lbl1.Text = ""
                lbl2.Text = ""
                lbl3.Text = ""
                lbl4.Text = ""
                txtP1.Enabled = False
                txtP2.Enabled = False
                txtP3.Enabled = False
                txtP4.Enabled = False
                lblOut.Text = ""
            Case "T"
                lblCmdName.Text = "Temperature"
                lblOut.Text = "        Temp"
            Case "X"
                lblCmdName.Text = "Turn Off"
                lbl1.Text = ""
                lbl2.Text = ""
                lbl3.Text = ""
                lbl4.Text = ""
                txtP1.Enabled = False
                txtP2.Enabled = False
                txtP3.Enabled = False
                txtP4.Enabled = False
                lblOut.Text = ""
            Case "Z"
                lblCmdName.Text = "Counter"
                lbl1.Text = ""
                lbl2.Text = ""
                lbl3.Text = ""
                lbl4.Text = ""
                txtP1.Enabled = False
                txtP2.Enabled = False
                txtP3.Enabled = False
                txtP4.Enabled = False
                lblOut.Text = ""
        End Select
    End Sub

    Private Sub cmdQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdQuit.Click
        Dim choice As Integer
        choice = MsgBox("Are you sure you want to quit?", MsgBoxStyle.YesNo)
        If choice = MsgBoxResult.Yes Then
            myFinch.quit()
            Me.Close()
        End If
    End Sub
End Class