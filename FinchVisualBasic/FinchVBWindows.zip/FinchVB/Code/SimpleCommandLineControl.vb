﻿''' <summary>
''' Command Line Finch
''' Author: Daragh Egan
''' Date: 6/13/11
''' 
''' A simple command line application to test out the Finch class.
''' </summary>
''' <remarks></remarks>

Public Class SimpleCommandLineControl

    Public Shared Sub main()
        Dim myFinch As Finch = New Finch()
        Dim acc(3) As Double
        Dim lit(2) As Integer
        Dim obs(2) As Boolean
        Dim choice As Char = ""
        Dim temp As Double
        Dim lSpeed As Integer = 0
        Dim rSpeed As Integer = 0
        Dim rLED As Integer
        Dim gLED As Integer
        Dim bLED As Integer
        Dim freq As Integer
        Dim shaken As Boolean
        Dim tapped As Boolean

        printMenu()

        While (choice <> "Q")
            Console.WriteLine()
            Console.Write("Enter a command: ")
            choice = Chr(Console.Read())
            Console.ReadLine()

            Select Case choice
                Case "A"
                    acc = myFinch.getAccelerations()
                    Console.WriteLine("X: " & acc(0) & ", Y: " & acc(1) & ", Z: " & acc(2))

                Case "o"
                    Console.WriteLine("Level: " & myFinch.isFinchLevel())
                    Console.WriteLine("Beak Up: " & myFinch.isBeakUp())
                    Console.WriteLine("Beak Down: " & myFinch.isBeakDown())
                    Console.WriteLine("Upside Down: " & myFinch.isFinchUpsideDown())
                    Console.WriteLine("Left Wing Down: " & myFinch.isLeftWingDown())
                    Console.WriteLine("Right Wing Down: " & myFinch.isRightWingDown())

                Case "L"
                    lit = myFinch.getLightSensors()
                    Console.WriteLine("Left: " & lit(0) & ", Right: " & lit(1))

                Case "I"
                    obs = myFinch.getObstacleSensors()
                    Console.WriteLine("Left: " & obs(0) & ", Right: " & obs(0))

                Case "T"
                    temp = myFinch.getTemperature()
                    Console.WriteLine(temp & " degrees Celsius")

                Case "S"
                    shaken = myFinch.isShaken()
                    Console.WriteLine("Shaken: " & shaken)

                Case "t"
                    tapped = myFinch.isTapped()
                    Console.WriteLine("Tapped: " & tapped)

                Case "B"
                    Console.Write("Frequency (Hz): ")
                    freq = Convert.ToInt32(Console.ReadLine)
                    myFinch.startBuzz(freq)

                Case "b"
                    myFinch.stopBuzz()

                Case "M"
                    Console.Write("Enter left wheel speed (-255 - 255): ")
                    lSpeed = Convert.ToInt16(Console.ReadLine())
                    Console.Write("Enter right wheel speed (-255 - 255): ")
                    rSpeed = Convert.ToInt16(Console.ReadLine())
                    myFinch.setWheelVelocities(lSpeed, rSpeed)

                Case "X"
                    myFinch.stopWheels()

                Case "O"
                    Console.Write("Enter red color value (0 - 255): ")
                    rLED = Convert.ToByte(Console.ReadLine())
                    Console.Write("Enter green color value (0 - 255): ")
                    gLED = Convert.ToByte(Console.ReadLine())
                    Console.Write("Enter blue color value (0 - 255): ")
                    bLED = Convert.ToByte(Console.ReadLine())
                    myFinch.setLED(rLED, gLED, bLED)
                Case Else
                    printMenu()

            End Select
        End While

    End Sub

    Private Shared Sub printMenu()
        Console.WriteLine("Finch Test Menu:")
        Console.WriteLine("A - print accelerometer values")
        Console.WriteLine("o - print orientation state")
        Console.WriteLine("L - print light sensor values")
        Console.WriteLine("I - print IR sensor values")
        Console.WriteLine("T - print temperature")
        Console.WriteLine("S - print if Finch has been shaken")
        Console.WriteLine("t - print if Finch has been tapped.")
        Console.WriteLine("B - turn on buzzer")
        Console.WriteLine("b - turn off buzzer")
        Console.WriteLine("M - turn on Motors")
        Console.WriteLine("X - motor stop")
        Console.WriteLine("O - set beak LED")
        Console.WriteLine("m - print menu")
        Console.WriteLine("Q - quit program")
    End Sub

End Class
