﻿Public Class FinchControlPanel
    Dim myFinch As Finch = New Finch()

    ' ***** LED Controls *****

    Private Sub refreshColor()
        lblColor.BackColor = Color.FromArgb(255, tbrRed.Value(), tbrGreen.Value(), tbrBlue.Value())
    End Sub

    Private Sub cmdLED_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLED.Click
        myFinch.setLED(tbrRed.Value, tbrGreen.Value, tbrBlue.Value)
    End Sub

    ' *** Change text to match sliders ***

    Private Sub tbrRed_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrRed.Scroll
        txtRed.Text = tbrRed.Value
        refreshColor()
    End Sub

    Private Sub tbrGreen_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrGreen.Scroll
        txtGreen.Text = tbrGreen.Value
        refreshColor()
    End Sub

    Private Sub tbrBlue_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrBlue.Scroll
        txtBlue.Text = tbrBlue.Value
        refreshColor()
    End Sub

    ' *** Change sliders to match text ***

    Private Sub txtRed_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRed.TextChanged
        tbrRed.Value = CInt(txtRed.Text)
        refreshColor()
    End Sub

    Private Sub txtGreen_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtGreen.TextChanged
        tbrGreen.Value = CInt(txtGreen.Text)
        refreshColor()
    End Sub

    Private Sub txtBlue_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtBlue.TextChanged
        tbrBlue.Value = CInt(txtBlue.Text)
        refreshColor()
    End Sub

    ' ***** Buzzer Controls *****

    Private Sub cmdBuzz_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBuzz.Click
        myFinch.buzz(tbrDuration.Value, tbrFrequency.Value)
    End Sub

    ' *** Change text to match sliders

    Private Sub tbrDuration_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrDuration.Scroll
        txtDuration.Text = tbrDuration.Value
    End Sub

    Private Sub tbrFrequency_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrFrequency.Scroll
        txtFrequency.Text = tbrFrequency.Value
    End Sub

    ' *** Change sliders to match text ***

    Private Sub txtDuration_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDuration.TextChanged
        tbrDuration.Value = CInt(txtDuration.Text)
    End Sub

    Private Sub txtFrequency_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFrequency.TextChanged
        tbrFrequency.Value = CInt(txtFrequency.Text)
    End Sub

    ' ***** Motor Controls *****

    Private Sub moveMotors()

        If chkMove.Checked Then
            myFinch.setWheelVelocities(tbrLeftMotor.Value, tbrRightMotor.Value)
        Else
            myFinch.stopWheels()
        End If
    End Sub

    Private Sub chkMove_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkMove.CheckedChanged
        moveMotors()
    End Sub

    ' *** Change text to match sliders *****

    Private Sub tbrLeftMotor_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrLeftMotor.Scroll
        txtLeftMotor.Text = tbrLeftMotor.Value

        If chkSyncMotors.Checked Then
            tbrRightMotor.Value = tbrLeftMotor.Value
            txtRightMotor.Text = txtLeftMotor.Text
        End If

        moveMotors()
    End Sub

    Private Sub tbrRightMotor_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrRightMotor.Scroll
        txtRightMotor.Text = tbrRightMotor.Value

        If chkSyncMotors.Checked Then
            tbrLeftMotor.Value = tbrRightMotor.Value
            txtLeftMotor.Text = txtRightMotor.Text
        End If

        moveMotors()
    End Sub

    ' *** Change sliders to match text ***

    Private Sub txtLeftMotor_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLeftMotor.TextChanged
        If chkSyncMotors.Checked Then
            tbrRightMotor.Value = tbrLeftMotor.Value
            txtRightMotor.Text = txtLeftMotor.Text
        End If

        tbrLeftMotor.Value = CInt(txtLeftMotor.Text)
        moveMotors()
    End Sub

    Private Sub txtRightMotor_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRightMotor.TextChanged
        If chkSyncMotors.Checked Then
            tbrLeftMotor.Value = tbrRightMotor.Value
            txtLeftMotor.Text = txtRightMotor.Text
        End If

        tbrRightMotor.Value = CInt(txtRightMotor.Text)
        moveMotors()
    End Sub

    Private Sub chkRead_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRead.CheckedChanged

        If chkRead.Checked Then
            chkRead.Text = "Stop Reading"
            tmrRead.Enabled = True
        Else
            chkRead.Text = "Read Sensors"
            tmrRead.Enabled = False
        End If

    End Sub

    Private Sub tmrRead_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRead.Tick
        Dim acc As Double()
        Dim obs As Boolean()
        Dim lit As Integer()
        Dim tmp As Double

        If myFinch.isConnected Then

            If chkObs.Checked Then

                obs = myFinch.getObstacleSensors()

                If obs(0) Then
                    lblLeftObs.BackColor = Color.Black
                Else
                    lblLeftObs.BackColor = Color.White
                End If

                If obs(1) Then
                    lblRightObs.BackColor = Color.Black
                Else
                    lblRightObs.BackColor = Color.White
                End If
            End If

            If chkAcc.Checked Then
                acc = myFinch.getAccelerations()

                If acc(0) * 10 < tbrX.Maximum And acc(0) * 10 > tbrX.Minimum Then
                    tbrX.Value = acc(0) * 10
                    lblX.Text = Format(acc(0), "###.00")
                End If
                If acc(1) * 10 < tbrY.Maximum And acc(1) * 10 > tbrY.Minimum Then
                    tbrY.Value = acc(1) * 10
                    lblY.Text = Format(acc(1), "###.00")
                End If
                If acc(2) * 10 < tbrZ.Maximum And acc(2) * 10 > tbrZ.Minimum Then
                    tbrZ.Value = acc(2) * 10
                    lblZ.Text = Format(acc(2), "###.00")
                End If
            End If

            If chkLight.Checked Then
                lit = myFinch.getLightSensors()

                If lit(0) < tbrLeftLight.Maximum Then
                    tbrLeftLight.Value = lit(0)
                    lblLlight.Text = lit(0)
                End If
                If lit(1) < tbrRightLight.Maximum Then
                    tbrRightLight.Value = lit(1)
                    lblRlight.Text = lit(1)
                End If

            End If

            If chkTemp.Checked Then
                tmp = myFinch.getTemperature()

                If tmp < tbrTemp.Maximum And tmp > 0 Then
                    tbrTemp.Value = tmp
                    lblTemp.Text = Format(tmp, "###.00")
                End If

            End If
        End If
    End Sub

    Private Sub cmdClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClear.Click
        tbrLeftLight.Value = 0
        tbrRightLight.Value = 0
        lblLlight.Text = "0.00"
        lblRlight.Text = "0.00"
        lblX.Text = "0.00"
        lblY.Text = "0.00"
        lblZ.Text = "0.00"
        lblTemp.Text = "0.00"
        tbrX.Value = 0
        tbrY.Value = 0
        tbrZ.Value = 0
        tbrTemp.Value = 0
        lblLeftObs.BackColor = Color.White
        lblRightObs.BackColor = Color.White
    End Sub
End Class