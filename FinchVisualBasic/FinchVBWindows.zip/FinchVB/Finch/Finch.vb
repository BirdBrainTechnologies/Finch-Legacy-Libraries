﻿Imports FinchHID.FinchHID
Imports System.Threading
Imports System.Timers

''' <summary>
''' Finch.vb
''' Used to control the Finch robot.
''' Author: Daragh Egan
''' Date: 6/13/11
''' </summary>

Public Class Finch
    Private myFinchHID As New FinchHID()    ' Class for communicating with HIDs
    Private connected As Boolean            ' True if connected to Finch
    Private count As Integer = 1            ' Incremented value for making reports unique
    Private tmrWakeup As Timers.Timer       ' Stops the Finch from falling asleep
    Private shaken, tapped As Boolean       ' True is Finch was Tapped or Shaken

    ''' <summary>
    ''' Initialize the Finch object
    ''' Set the HID and attempt to establish a connection.
    ''' </summary>
    Public Sub New()
        myFinchHID.Setup()
        createLogFile()
        writeToLog(" ")
        writeToLog("'''''''''' Finch ''''''''''")
        writeToLog("Attempting to connect to Finch...")
        connect()

        ' Set up timer to keep Finch awake
        ' Timer goes off every 4 seconds
        ' Finch resets after 5 seconds of inactivity
        tmrWakeup = New System.Timers.Timer(4000)
        AddHandler tmrWakeup.Elapsed, AddressOf WakeUp

        If connected Then
            tmrWakeup.Enabled = True
            WakeUp(Nothing, Nothing)
        Else
            MsgBox("Connection Failed. Check Finch connection.", MsgBoxStyle.OkOnly)

        End If

    End Sub

    ''' <summary>
    ''' Tries to connect to the finch.
    ''' Called automatically when Finch is initialized.
    ''' </summary>
    Public Sub connect()
        Try
            connected = myFinchHID.FindTheHid()
        Catch ex As Exception
            DisplayException("Finch", ex)
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Check Finch connection status
    ''' </summary>
    ''' <returns>True if connected, false otherwise.</returns>
    ''' <remarks></remarks>
    Public Function isConnected() As Boolean
        Return connected
    End Function

    ''' <summary>
    ''' Plays the buzzer for a length of time at a frequency.
    ''' </summary>
    ''' <param name="duration">Duration of buzz in milliseconds.</param>
    ''' <param name="frequency">Frequency of buzz.</param>
    Public Sub buzz(ByVal duration As UInt16, ByVal frequency As UInt16)
        Dim writeBuffer As Byte()
        Dim hi_duration, lo_duration As Byte
        Dim hi_frequency, lo_frequency As Byte

        If connected Then
            ' Take the 8 highest bits
            ' Shift right 8 bits
            hi_duration = Convert.ToByte(Int(duration / 256))
            ' Take the 8 lowest bits
            lo_duration = Convert.ToByte(Int(duration - hi_duration * 256))

            ' Take the 8 highest bits
            ' Shift right 8 bits
            hi_frequency = Convert.ToByte(Int(frequency / 256))
            ' Take the 8 lowest bits
            lo_frequency = Convert.ToByte(Int(frequency - hi_frequency * 256))

            writeBuffer = New Byte() {0, Asc("B"), hi_duration, lo_duration, hi_frequency, lo_frequency}

            Try ' Split the 16-bit integers into to bytes each
                sendData(writeBuffer, False)
                sleep(duration)

            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If
       
    End Sub

    ''' <summary>
    ''' Gets the value (True or False) of the bit in num at index. 
    ''' Example: 
    ''' 4 is 00000100 in binary
    ''' getBit(4, 1) returns False
    ''' getBit(4, 2) returns True
    ''' </summary>
    ''' <param name="num"></param>
    ''' <param name="index"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getBit(ByVal num As Byte, ByVal index As Integer) As Boolean
        For i As Integer = 0 To index
            num = num / 2
        Next i

        Return (num Mod 2) = 1
    End Function

    ''' <summary>
    ''' Reads accelerometer values.
    ''' </summary>
    ''' <returns>Array of three integers: x, y, and z values.</returns>
    Public Function getAccelerations() As Double()
        Dim writeBuffer As Byte()
        Dim readBuffer(0 To 8) As Byte
        Dim acc As Double() = New Double() {0, 0, 0}

        If connected Then
            Try
                writeBuffer = New Byte() {0, Asc("A")}
                readBuffer = sendData(writeBuffer, True)

                ' Convert into G force
                For i As Integer = 0 To 2
                    If readBuffer(i + 2) > 31 Then
                        acc(i) = (readBuffer(i + 2) - 64) * 1.5 / 32
                    Else
                        acc(i) = readBuffer(i + 2) * 1.5 / 32
                    End If
                Next i

                'shaken = shaken or (bit 7 at readBuffer(4) )
                'shaken = shaken || ( (readBuffer[4] & (1<<7)) >> 7 )
                shaken = shaken Or getBit(readBuffer(5), 7)

                'tapped = tapped or (bit 5 at readBuffer(4) )
                'tapped = tapped || ( (readBuffer[4] & (1<<5)) >> 5 )
                tapped = tapped Or getBit(readBuffer(5), 5)

            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If

        Return acc
    End Function

    ''' <summary>
    ''' Returns the value of the left light sensor.
    ''' </summary>
    ''' <returns>Intensity of light falling on left sensor (range is 0 to 255).</returns>
    Public Function getLeftLightSensor() As Integer
        Dim input As Integer() = getLightSensors()
        Return input(0)
    End Function

    ''' <summary>
    ''' Gets values being read by the light sensors.
    ''' </summary>
    ''' <returns>Array of two integers: left and right sensors. Intesity of light (0-255).</returns>
    Public Function getLightSensors() As Integer()
        Dim writeBuffer As Byte()
        Dim readBuffer(0 To 8) As Byte
        Dim light As Integer() = New Integer() {0, 0}

        If connected Then
            writeBuffer = New Byte() {0, Asc("L")}

            Try
                readBuffer = sendData(writeBuffer, True)
                light(0) = readBuffer(1)
                light(1) = readBuffer(2)

            Catch ex As Exception
                DisplayException("Finch", ex)
            End Try
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If

        Return light
    End Function

    ''' <summary>
    ''' Reads obstacle sensors.
    ''' </summary>
    ''' <returns>Array of two booleans: left and right sensors. True if object is present, false if not.</returns>
    Public Function getObstacleSensors() As Boolean()
        Dim writeBuffer As Byte()
        Dim readBuffer(0 To 8) As Byte
        Dim obs As Boolean() = New Boolean() {False, False}

        If connected Then
            writeBuffer = New Byte() {0, Asc("I")}

            Try
                readBuffer = sendData(writeBuffer, True)
                obs(0) = readBuffer(1)
                obs(1) = readBuffer(2)

            Catch ex As Exception
                DisplayException("Finch", ex)
            End Try
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If

        Return obs
    End Function

    ''' <summary>
    ''' Returns the value of the right light sensor.
    ''' </summary>
    ''' <returns>Intensity of light falling on left sensor (range is 0 to 255).</returns>
    Public Function getRightLightSensor() As Integer
        Dim input As Integer() = getLightSensors()
        Return input(1)
    End Function

    ''' <summary>
    ''' Reads temperature as measured by Finch's nose sensor.
    ''' </summary>
    ''' <returns>Temperature in Celcius.</returns>
    Public Function getTemperature() As Double
        Dim writeBuffer As Byte()
        Dim readBuffer(0 To 8) As Byte
        Dim temp As Double = 0

        If connected Then
            writeBuffer = New Byte() {0, Asc("T")}

            Try
                readBuffer = sendData(writeBuffer, True)
                temp = Convert.ToDouble(readBuffer(1))
                ' Convert to Celsius
                temp = (readBuffer(1) - 127) / 2.4 + 25

            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try

        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If

        Return temp
    End Function

    ''' <summary>
    ''' Returns the acceleration experienced by the Finch on the X axis.
    ''' </summary>
    ''' <returns>Acceleration in gees (range is -1.5 to 1.5).</returns>
    ''' <remarks></remarks>
    Public Function getXAcceleration() As Double
        Dim input As Double() = getAccelerations()
        Return input(0)
    End Function

    ''' <summary>
    ''' Returns the acceleration experienced by the Finch on the Y axis.
    ''' </summary>
    ''' <returns>Acceleration in gees (range is -1.5 to 1.5).</returns>
    Public Function getYAcceleration() As Double
        Dim input As Double() = getAccelerations()
        Return input(1)
    End Function

    ''' <summary>
    ''' Returns the acceleration experienced bt the Finch on the Z axis.
    ''' </summary>
    ''' <returns>Acceleration in gees (range is -1.5 to 1.5).</returns>
    Public Function getZAcceleration() As Double
        Dim input As Double() = getAccelerations()
        Return input(2)
    End Function

    ''' <summary>
    ''' Uses the accelerometer to determine orientation.
    ''' </summary>
    ''' <returns> True if beak is facing down, false otherwise.</returns>
    Public Function isBeakDown() As Boolean
        Dim acc() As Double = getAccelerations()
        ' accels[0] < 1.5 && accels[0] > 0.8 && accels[1] > -0.3 && accels[1] < 0.3 && accels[2] > -0.3 && accels[2] < 0.3)
        Return acc(0) < 1.5 And acc(0) > 0.8 And acc(1) > -0.3 And acc(1) < 0.3 And acc(2) > -0.3 And acc(2) < 0.3
    End Function

    ''' <summary>
    ''' Uses the accelerometer to determine orientation.
    ''' </summary>
    ''' <returns> True if beak is facing up, false otherwise. </returns>
    Public Function isBeakUp() As Boolean
        Dim acc() As Double = getAccelerations()
        ' accels[0] < -0.8 && accels[0] > -1.5 && accels[1] > -0.3 && accels[1] < 0.3 && accels[2] > -0.3 && accels[2] < 0.3)
        Return acc(0) < -0.8 And acc(0) > -1.5 And acc(1) > -0.3 And acc(1) < 0.3 And acc(2) > -0.3 And acc(2) < 0.3
    End Function

    ''' <summary>
    ''' Uses the accelerometer to determine orientation.
    ''' </summary>
    ''' <returns> True if Finch is flat on a surface, false otherwise. </returns>
    Public Function isFinchLevel() As Boolean
        Dim acc() As Double = getAccelerations()
        ' accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > -0.5 && accels[1] < 0.5 && accels[2] > 0.65 && accels[2] < 1.5)
        Return acc(0) > -0.5 And acc(0) < 0.5 And acc(1) > -0.5 And acc(1) < 0.5 And acc(2) > 0.65 And acc(2) < 1.5
    End Function

    ''' <summary>
    ''' Uses the accelerometer to determine orientation.
    ''' </summary>
    ''' <returns> True if Finch is upside down, false otherwise. </returns>
    Public Function isFinchUpsideDown() As Boolean
        Dim acc() As Double = getAccelerations()
        'accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > -0.5 && accels[1] < 0.5 && accels[2] > -1.5 && accels[2] < -0.65)
        Return acc(0) > -0.5 And acc(0) < 0.5 And acc(1) > -0.5 And acc(1) < 0.5 And acc(2) > -1.5 And acc(2) < -0.65
    End Function

    ''' <summary>
    ''' Simple way to test the left light sensor's value against a limit.
    ''' </summary>
    ''' <param name="limit">The value to test the light sensor against</param>
    ''' <returns>True if the left light sensor is less than the value specified, false otherwise.</returns>
    Public Function isLeftLightSensor(ByVal limit As Integer) As Boolean
        Return getLeftLightSensor() < limit
    End Function

    ''' <summary>
    ''' Uses the accelerometer to determine orientation.
    ''' </summary>
    ''' <returns> True if the left wing is down, false otherwise. </returns>
    Public Function isLeftWingDown() As Boolean
        Dim acc() As Double = getAccelerations()
        'accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > 0.7 && accels[1] < 1.5 && accels[2] > -0.5 && accels[2] < 0.5)
        Return acc(0) > -0.5 And acc(0) < 0.5 And acc(1) > 0.7 And acc(1) < 1.5 And acc(2) > -0.5 And acc(2) < 0.5
    End Function

    ''' <summary>
    ''' Simple check to see if there is an obstacle detected.  
    ''' </summary>
    ''' <returns>true if an obstacle is detected on the left OR right side, false otherwise.</returns>
    Public Function isObstacle() As Boolean
        Return isObstacleLeftside() Or isObstacleRightSide()
    End Function

    ''' <summary>
    ''' Checks the left obstacle sensor.
    ''' </summary>
    ''' <returns>True if an obstacle is detected on the left side, false otherwise.</returns>
    Public Function isObstacleLeftside() As Boolean
        Dim obs() As Boolean = getObstacleSensors()
        Return obs(0)
    End Function

    ''' <summary>
    ''' Checks the right obstacle sensor.
    ''' </summary>
    ''' <returns>True if an obstacle is detected on the right side, false otherwise.</returns>
    Public Function isObstacleRightSide() As Boolean
        Dim obs() As Boolean = getObstacleSensors()
        Return obs(1)
    End Function

    ''' <summary>
    ''' Simple way to test the right light sensor's value against a limit.
    ''' </summary>
    ''' <param name="limit">The value to test the light sensor against</param>
    ''' <returns>True if the right light sensor is less than the value specified, false otherwise.</returns>
    Public Function isRightLightSensor(ByVal limit As Integer) As Boolean
        Return getRightLightSensor() < limit
    End Function

    ''' <summary>
    ''' Uses the accelerometer to determine orientation.
    ''' </summary>
    ''' <returns> True if right wing is down, false otherwise. </returns>
    Public Function isRightWingDown() As Boolean
        Dim acc() As Double = getAccelerations()
        'accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > -1.5 && accels[1] < -0.7 && accels[2] > -0.5 && accels[2] < 0.5)
        Return acc(0) > -0.5 And acc(0) < 0.5 And acc(1) > -1.5 And acc(1) < -0.7 And acc(2) > -0.5 And acc(2) < 0.5
    End Function

    ''' <summary>
    ''' Checks whether Finch has been shaken recently.
    ''' </summary>
    ''' <returns>True if the Finch has been shaken recently.</returns>
    Public Function isShaken() As Boolean
        getAccelerations()
        If shaken Then
            shaken = False
            Return True
        Else
            Return False
        End If
    End Function

    ''' <summary>
    ''' Checks if the accelerometer detected a tap recently.
    ''' </summary>
    ''' <returns>True if the Finch has been tapped recently.</returns>
    ''' <remarks></remarks>
    Public Function isTapped() As Boolean
        getAccelerations()
        If tapped Then
            tapped = False
            Return True
        Else
            Return False
        End If
    End Function

    ''' <summary>
    ''' Checks the current temperature against a value.
    ''' </summary>
    ''' <param name="limit">The value to check temperature against</param>
    ''' <returns>True if the temperature is less than the specified value, false otherwise.</returns>
    Public Function isTemperature(ByVal limit As Double) As Boolean
        Return getTemperature() < limit
    End Function

    ''' <summary>
    ''' Disconnects the Finch from the application and returns it to idle mode. 
    ''' </summary>
    Public Sub quit()
        Dim writeBuffer As Byte()

        If connected Then
            writeBuffer = New Byte() {0, Asc("X")}

            Try
                sendData(writeBuffer, False)

            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try
        End If
    End Sub

    ''' <summary>
    ''' Sets the LED to the specified color.
    ''' </summary>
    ''' <param name="red">Red value (1 byte)</param>
    ''' <param name="green">Green value (1 byte)</param>
    ''' <param name="blue">Blue value (1 byte)</param>
    Public Sub setLED(ByVal red As UInteger, ByVal green As UInteger, ByVal blue As UInteger)
        Dim writeBuffer As Byte()

        If connected Then
            writeBuffer = New Byte() {0, Asc("O"), Convert.ToByte(red), Convert.ToByte(green), Convert.ToByte(blue)}

            Try
                sendData(writeBuffer, False)

            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If

    End Sub

    ''' <summary>
    ''' Sets the LED for an amount of time.
    ''' </summary>
    ''' <param name="red">Red value (1 byte)</param>
    ''' <param name="green">Green value (1 byte)</param>
    ''' <param name="blue">Blue value (1 byte)</param>
    ''' <param name="duration"> Time to hold in milliseconds. </param>
    Public Sub setLED(ByVal red As UInteger, ByVal green As UInteger, ByVal blue As UInteger, ByVal duration As UInteger)
        setLED(red, green, blue)
        sleep(duration)
    End Sub

    ''' <summary>
    ''' Moves left and right motors. Positive values are forward and negative values are backward.
    ''' </summary>
    ''' <param name="leftvelocity">Speed between -255 and 255.</param>
    ''' <param name="rightvelocity">Speed between -255 and 255.</param>
    '''
    Public Sub setWheelVelocities(ByVal leftvelocity As Integer, ByVal rightvelocity As Integer)
        Dim writeBuffer As Byte()
        Dim rdir As Integer = 0 ' Right motor direction. (0 forward, 1 backward)
        Dim ldir As Integer = 0 ' Left motor direction. (0 forward, 1 backward)

        If connected Then
            If rightvelocity < 0 Then
                rdir = 1
                rightvelocity = rightvelocity * -1
            End If

            If leftvelocity < 0 Then
                ldir = 1
                leftvelocity = leftvelocity * -1
            End If

            If rightvelocity > 255 Then
                rightvelocity = 255
            End If

            If leftvelocity > 255 Then
                leftvelocity = 255
            End If

            writeBuffer = New Byte() {0, Asc("M"), ldir, Convert.ToByte(leftvelocity), rdir, Convert.ToByte(rightvelocity)}

            Try
                sendData(writeBuffer, False)

            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If


    End Sub

    ''' <summary>
    ''' Moves the left and right motors for a duration of time.
    ''' </summary>
    ''' <param name="leftvelocity">Speed between -255 and 255.</param>
    ''' <param name="rightvelocity">Speed between -255 and 255.</param>
    ''' <param name="duration"> Time to hold in milliseconds. </param>
    Public Sub setWheelVelocities(ByVal leftVelocity As Integer, ByVal rightVelocity As Integer, ByVal duration As UInteger)
        setWheelVelocities(leftVelocity, rightVelocity)
        sleep(duration)
        stopWheels()
    End Sub

    ''' <summary>
    ''' Pauses the current thread.
    ''' </summary>
    ''' <param name="ms"> Duration is milliseconds. </param>
    Public Sub sleep(ByVal ms As UInteger)
        Thread.Sleep(ms)
    End Sub

    ''' <summary>
    ''' Turn the buzzer off.
    ''' </summary>
    Public Sub stopBuzz()
        buzz(0, 0)
    End Sub

    ''' <summary>
    ''' Turn the buzzer on until stopBuzz is called.
    ''' </summary>
    ''' <param name="frequency">The frequency in Hertz to set the buzzer to.</param>
    ''' <remarks></remarks>
    Public Sub startBuzz(ByVal frequency As Int16)
        Dim writeBuffer As Byte()
        Dim hi_duration, lo_duration As Byte
        Dim hi_frequency, lo_frequency As Byte

        If connected Then
            ' The 8 highest bits
            hi_duration = Convert.ToByte(255)
            ' The 8 lowest bits
            lo_duration = Convert.ToByte(255)

            ' Take the 8 highest bits
            ' Shift right 8 bits
            hi_frequency = Convert.ToByte(Int(frequency / 256))
            ' Take the 8 lowest bits
            lo_frequency = Convert.ToByte(Int(frequency - hi_frequency * 256))

            writeBuffer = New Byte() {0, Asc("B"), hi_duration, lo_duration, hi_frequency, lo_frequency}

            Try ' Split the 16-bit integers into to bytes each
                sendData(writeBuffer, False)

            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If
    End Sub

    ''' <summary>
    ''' Sets the wheel velocities to zero.
    ''' </summary>
    Public Sub stopWheels()
        setWheelVelocities(0, 0)
    End Sub

    ''' <summary>
    ''' Sends an array of 9 bytes to the finch as output.
    ''' Returns input from Finch only if hasReply is True.
    ''' </summary>
    ''' <param name="writeBuffer"> Ouput to send to Finch. </param>
    ''' <param name="hasReply"> Tells the function whether or not to expect and return input data. </param>
    ''' <returns> Array of bytes from the Finch if requested. </returns>
    Public Function sendData(ByVal writeBuffer() As Byte, ByVal hasReply As Boolean) As Byte()
        Dim readBuffer(0 To 8) As Byte

        If connected Then
            ' The last byte must change in order to update reply
            count = count + 1
            If count > 255 Then
                count = 1
            End If

            Array.Resize(writeBuffer, 9)
            writeBuffer(8) = Convert.ToByte(count)

            ' Turn off wakeup timer so it doesn't try to read while we're busy.
            ' Besides, the fact that we're reading makes the timer unnecessary for the moment.
            tmrWakeup.Enabled = False

            ' Give the Finch some time to breath
            sleep(15)

            Try
                ' Use the HID interface to communicate with the Finch
                'readBuffer = myFinchHID.ReadAndWriteToDevice(writeBuffer, hasReply)
                myFinchHID.writeHID(writeBuffer)
                readBuffer = myFinchHID.readHID(count)

                If readBuffer Is Nothing Then
                    connected = False
                    Debug.WriteLine("The Finch is not responding. Check Finch connection.")
                End If

            Catch ex As System.IO.IOException
                DisplayException("Finch", ex)
                connected = False
            Catch ex As Exception
                DisplayException("Finch", ex)
                Throw
            End Try

            tmrWakeup.Enabled = True
        Else
            Debug.WriteLine("Error. Check Finch connection.")
        End If

        Return readBuffer
    End Function

    ''' <summary>
    ''' Called by the timer to prevent the Finch from falling asleep.
    ''' </summary>
    ''' <param name="source"></param>
    ''' <param name="e"></param>
    Private Sub WakeUp(ByVal source As Object, ByVal e As ElapsedEventArgs)
        If connected Then
            getTemperature()
        End If
    End Sub

End Class