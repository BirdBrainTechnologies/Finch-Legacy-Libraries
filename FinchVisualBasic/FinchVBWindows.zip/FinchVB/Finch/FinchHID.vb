﻿Imports FinchHID.Hid
Imports FinchHID.DeviceManagement
Imports Microsoft.Win32.SafeHandles
Imports FinchHID.FileIO
Imports System.Runtime.InteropServices
Imports System.IO
Imports System.Globalization
Imports System.Timers

''' <summary>
''' FinchHID.vb
''' Used by the Finch class to comunicate with the Finch as an HID.
''' Author: Daragh Egan
''' Reference: Jan Axelson's GenericHID
''' Date: 6/2/11
''' </summary>

Friend Class FinchHID

    Private myDeviceDetected As Boolean
    Private MyDebugging As New Debugging() ' For viewing results of API calls via Debug.Write.
    Private MyDeviceManagement As New DeviceManagement()
    Private hidHandle As SafeFileHandle
    Private MyHid As New Hid()
    Private myDevicePathName As String
    Private deviceNotificationHandle As IntPtr
    Private hidUsage As String
    Private exclusiveAccess As Boolean
    Private fileStreamdevicedata As FileStream
    Private transferInProgress As Boolean = False
    Private Shared tmrReadTimeout As System.Timers.Timer
    Private Shared logFile As String = "Finch.log"
    Private Shared logBuffer As String = ""
    Private readBuffer(256)() As Byte ' Buffer of input reports


    ''' <summary>
    ''' Perform actions that must execute when the program starts.
    ''' </summary>

    Friend Sub Setup()

        Try
            MyHid = New Hid()

            tmrReadTimeout = New System.Timers.Timer(5000)
            AddHandler tmrReadTimeout.Elapsed, AddressOf OnReadTimeout
            'tmrReadTimeout.SynchronizingObject = Me
            tmrReadTimeout.Stop()

        Catch ex As Exception
            DisplayException("FinchMain", ex)
            Throw
        End Try

    End Sub

    ''' <summary>
    ''' Finds and displays the number of Input buffers
    ''' (the number of Input reports the host will store). 
    ''' </summary>

    Private Sub GetInputReportBufferSize()

        Dim numberOfInputBuffers As Int32

        Try
            ' Get the number of input buffers.

            MyHid.GetNumberOfInputBuffers _
             (hidHandle, _
             numberOfInputBuffers)

        Catch ex As Exception
            'DisplayException(Me.Name, ex)
            Throw
        End Try

    End Sub

    ''' <summary>
    ''' Uses a series of API calls to locate a HID-class device
    ''' by its Vendor ID and Product ID.
    ''' </summary>
    '''         
    ''' <returns>
    '''  True if the device is detected, False if not detected.
    ''' </returns>

    friend Function FindTheHid() As Boolean

        Dim deviceFound As Boolean
        Dim devicePathName(127) As String
        Dim hidGuid As System.Guid
        Dim inputReportBuffer As Byte() = Nothing
        Dim memberIndex As Int32
        Dim myVendorID As Int32 = Int32.Parse("2354", NumberStyles.AllowHexSpecifier)
        Dim myProductID As Int32 = Int32.Parse("1111", NumberStyles.AllowHexSpecifier)
        Dim outputReportBuffer As Byte() = Nothing
        Dim success As Boolean

        Try
            myDeviceDetected = False

            ' ***
            ' API function: 'HidD_GetHidGuid

            ' Purpose: Retrieves the interface class GUID for the HID class.

            ' Accepts: 'A System.Guid object for storing the GUID.
            ' ***

            HidD_GetHidGuid(hidGuid)
            writeToLog("  GUID for system HIDs: " & hidGuid.ToString)

            ' Fill an array with the device path names of all attached HIDs.

            deviceFound = MyDeviceManagement.FindDeviceFromGuid _
             (hidGuid, _
             devicePathName)

            ' If there is at least one HID, attempt to read the Vendor ID and Product ID
            ' of each device until there is a match or all devices have been examined.

            If deviceFound Then

                memberIndex = 0

                Do
                    ' ***
                    ' API function:
                    ' CreateFile

                    ' Purpose:
                    ' Retrieves a handle to a device.

                    ' Accepts:
                    ' A device path name returned by SetupDiGetDeviceInterfaceDetail
                    ' The type of access requested (read/write).
                    ' FILE_SHARE attributes to allow other processes to access the device while this handle is open.
                    ' A Security structure or IntPtr.Zero. 
                    ' A creation disposition value. Use OPEN_EXISTING for devices.
                    ' Flags and attributes for files. Not used for devices.
                    ' Handle to a template file. Not used.

                    ' Returns: a handle without read or write access.
                    ' This enables obtaining information about all HIDs, even system
                    ' keyboards and mice. 
                    ' Separate handles are used for reading and writing.
                    ' ***

                    ' Open the handle without read/write access to enable getting information about any HID, even system keyboards and mice.

                    hidHandle = CreateFile _
                     (devicePathName(memberIndex), _
                     0, _
                     FILE_SHARE_READ Or FILE_SHARE_WRITE, _
                     IntPtr.Zero, _
                     OPEN_EXISTING, _
                     0, _
                     0)

                    writeToLog("  Returned handle: " & hidHandle.ToString)

                    If Not (hidHandle.IsInvalid) Then

                        ' The returned handle is valid, 
                        ' so find out if this is the device we're looking for.

                        ' Set the Size property of DeviceAttributes to the number of bytes in the structure.

                        MyHid.DeviceAttributes.Size = Marshal.SizeOf(MyHid.DeviceAttributes)

                        ' ***
                        ' API function:
                        ' HidD_GetAttributes

                        ' Purpose:
                        ' Retrieves a HIDD_ATTRIBUTES structure containing the Vendor ID, 
                        ' Product ID, and Product Version Number for a device.

                        ' Accepts:
                        ' A handle returned by CreateFile.
                        ' A pointer to receive a HIDD_ATTRIBUTES structure.

                        ' Returns:
                        ' True on success, False on failure.
                        ' ***

                        success = HidD_GetAttributes(hidHandle, MyHid.DeviceAttributes)

                        If success Then

                            writeToLog("  HIDD_ATTRIBUTES structure filled without error.")
                            writeToLog("  Structure size: " & MyHid.DeviceAttributes.Size)
                            writeToLog("  Vendor ID: " & Hex(MyHid.DeviceAttributes.VendorID))
                            writeToLog("  Product ID: " & Hex(MyHid.DeviceAttributes.ProductID))
                            writeToLog("  Version Number: " & Hex(MyHid.DeviceAttributes.VersionNumber))

                            ' Find out if the device matches the one we're looking for.

                            If (MyHid.DeviceAttributes.VendorID = myVendorID) And _
                             (MyHid.DeviceAttributes.ProductID = myProductID) Then

                                writeToLog("  My device detected")

                                ' Display the information in form's list box.

                                writeToLog("Device detected:")
                                writeToLog("  Vendor ID= " & Hex(MyHid.DeviceAttributes.VendorID))
                                writeToLog("  Product ID = " & Hex(MyHid.DeviceAttributes.ProductID))

                                myDeviceDetected = True

                                ' Save the DevicePathName for OnDeviceChange().

                                myDevicePathName = devicePathName(memberIndex)
                            Else

                                ' It's not a match, so close the handle.

                                myDeviceDetected = False

                                hidHandle.Close()

                            End If

                        Else
                            ' There was a problem in retrieving the information.

                            writeToLog("  Error in filling HIDD_ATTRIBUTES structure.")
                            myDeviceDetected = False
                            hidHandle.Close()
                        End If

                    End If

                    ' Keep looking until we find the device or there are no devices left to examine.

                    memberIndex = memberIndex + 1

                Loop Until (myDeviceDetected Or (memberIndex = devicePathName.Length))

            End If

            If myDeviceDetected Then

                ' The device was detected.
                ' Register to receive notifications if the device is removed or attached.

                success = MyDeviceManagement.RegisterForDeviceNotifications _
                 (myDevicePathName, _
                 Nothing, _
                 hidGuid, _
                 deviceNotificationHandle)

                writeToLog("RegisterForDeviceNotifications = " & success)

                ' Learn the capabilities of the device.

                MyHid.Capabilities = MyHid.GetDeviceCapabilities(hidHandle)

                success = True

                If success Then

                    ' Find out if the device is a system mouse or keyboard.

                    hidUsage = MyHid.GetHidUsage(MyHid.Capabilities)

                    ' Get the Input report buffer size.

                    GetInputReportBufferSize()

                    'Close the handle and reopen it with read/write access.

                    hidHandle.Close()

                    hidHandle = CreateFile _
                     (myDevicePathName, _
                     GENERIC_READ Or GENERIC_WRITE, _
                     FILE_SHARE_READ Or FILE_SHARE_WRITE, _
                     IntPtr.Zero, _
                     OPEN_EXISTING, _
                     0, _
                     0)

                    If hidHandle.IsInvalid Then

                        exclusiveAccess = True
                        writeToLog("The device is a system " + hidUsage + ".")
                        writeToLog("Windows 2000 and Windows XP obtain exclusive access to Input and Output reports for this devices.")
                        writeToLog("Applications can access Feature reports only.")

                    Else

                        If (MyHid.Capabilities.InputReportByteLength > 0) Then

                            ' Set the size of the Input report buffer. 
                            ' Subtract 1 from the value in the Capabilities structure because 
                            ' the array begins at index 0.

                            Array.Resize(inputReportBuffer, MyHid.Capabilities.InputReportByteLength)

                            fileStreamdevicedata = New FileStream(hidHandle, FileAccess.Read Or FileAccess.Write, inputReportBuffer.Length, False)

                        End If

                        If (MyHid.Capabilities.OutputReportByteLength > 0) Then

                            ' Set the size of the Output report buffer. 
                            ' Subtract 1 from the value in the Capabilities structure because 
                            ' the array begins at index 0.

                            Array.Resize(outputReportBuffer, MyHid.Capabilities.OutputReportByteLength)

                        End If

                        ' Flush any waiting reports in the input buffer. (optional)

                        MyHid.FlushQueue(hidHandle)

                    End If
                End If
            Else
                ' The device wasn't detected.
                writeToLog(" Device not found.")
            End If

            Return myDeviceDetected

        Catch ex As Exception
            DisplayException("FinchMain", ex)
            Throw
        End Try
    End Function

    Friend Function writeHID(ByVal outputReportBuffer() As Byte) As Boolean
        Dim byteValue As String
        Dim count As Int32
        Dim inputReportBuffer() As Byte = Nothing
        Dim success As Boolean

        Try
            success = False

            ' Don't attempt to exchange reports if valid handles aren't available
            ' (as for a mouse or keyboard under Windows 2000/XP.)

            If (Not (hidHandle.IsInvalid)) Then

                ' Don't attempt to send an Output report if the HID has no Output report.

                If (MyHid.Capabilities.OutputReportByteLength > 0) Then

                    ' Set the upper bound of the Output report buffer. 
                    ' Subtract 1 from OutputReportByteLength because the array begins at index 0.

                    ' Make sure buffer is the right size. (Should be 9 for the Finch)
                    Array.Resize(outputReportBuffer, MyHid.Capabilities.OutputReportByteLength)

                    ' Write a report.
                    If (fileStreamdevicedata.CanWrite) Then
                        fileStreamdevicedata.Write(outputReportBuffer, 0, outputReportBuffer.Length)
                        success = True
                    Else
                        CloseCommunications()
                        writeToLog("The attempt to read an Input report has failed.")
                    End If


                    If success Then

                        writeToLog("An Output report has been written.")

                        ' Display the report data

                        writeToLog(" Output Report ID: " & String.Format("{0:X2} ", outputReportBuffer(0)))
                        writeToLog(" Output Report Data:")

                        For count = 1 To UBound(outputReportBuffer)

                            ' Display bytes as 2-character hex strings.

                            byteValue = String.Format("{0:X2} ", outputReportBuffer(count))
                            writeToLog(" " & byteValue)

                        Next count
                    Else
                        CloseCommunications()
                        writeToLog("The attempt to write an Output report failed.")
                    End If


                Else
                    writeToLog("The HID doesn't have an Output report.")
                End If

            Else
                writeToLog("Invalid handle. The device is probably a system mouse or keyboard.")
                writeToLog("No attempt to write an Output report or read an Input report was made.")
            End If

        Catch ex As Exception
            DisplayException("FinchMain", ex)
            Throw
        End Try

    End Function

    Friend Function readHID(ByVal id As Integer) As Byte()
        Dim inputReportBuffer() As Byte = Nothing
        Dim success As Boolean

        Try
            success = False

            ' Don't attempt to exchange reports if valid handles aren't available
            ' (as for a mouse or keyboard under Windows 2000/XP.)

            If (Not (hidHandle.IsInvalid)) Then
                ' Read an Input report.

                success = False

                ' Don't attempt to send an Input report if the HID has no Input report.
                ' (The HID spec requires all HIDs to have an interrupt IN endpoint,
                ' which suggests that all HIDs must support Input reports.)

                If (MyHid.Capabilities.InputReportByteLength > 0) Then

                    ' Set the size of the Input report buffer. 
                    Array.Resize(inputReportBuffer, MyHid.Capabilities.InputReportByteLength)

                    ' Read a report using interrupt transfers.                
                    ' To enable reading a report without blocking the main thread, this
                    ' application uses an asynchronous delegate.

                    'Dim ar As IAsyncResult = Nothing
                    transferInProgress = True

                    ' Timeout if no report is available.

                    tmrReadTimeout.Start()

                    If (fileStreamdevicedata.CanRead) Then

                        fileStreamdevicedata.BeginRead(inputReportBuffer, 0, inputReportBuffer.Length, New AsyncCallback(AddressOf GetInputReportData), inputReportBuffer)

                        ' Wait for input report to arrive
                        While (inputReportBuffer(UBound(inputReportBuffer)) = 0)
                        End While

                        ' Check input id with output id
                        If inputReportBuffer(8) <> id Then
                            ' If it's the wrong report, log in the buffer
                            ' and check buffer for correct report.
                            readBuffer(inputReportBuffer(8)) = inputReportBuffer
                            inputReportBuffer = readBuffer(id)
                            readBuffer(id) = Nothing
                        End If

                    Else
                        CloseCommunications()
                        writeToLog("The attempt to read an Input report has failed.")
                    End If
                Else

                    writeToLog("No attempt to read an Input report was made.")
                    writeToLog("The HID doesn't have an Input report.")
                End If
            Else
                writeToLog("Invalid handle. The device is probably a system mouse or keyboard.")
                writeToLog("No attempt to write an Output report or read an Input report was made.")
            End If

        Catch ex As Exception
            DisplayException("FinchMain", ex)
            Throw
        End Try

        Return inputReportBuffer

    End Function

    ''' <summary>
    ''' Sends an Output report, then retrieves an Input report.
    ''' Assumes report ID = 0 for both reports.
    ''' </summary>
    ''' 
    ''' <param name="outputReportBuffer"> Output report </param>
    ''' 
    ''' <param name="hasReply"> True if an input report is expected </param>
    '''
    ''' <returns> Input report from Finch </returns>

    Private Function ExchangeInputAndOutputReports(ByVal outputReportBuffer() As Byte, ByVal hasReply As Boolean) As Byte()

        Dim byteValue As String
        Dim count As Int32
        Dim inputReportBuffer() As Byte = Nothing
        Dim success As Boolean

        Try
            success = False

            ' Don't attempt to exchange reports if valid handles aren't available
            ' (as for a mouse or keyboard under Windows 2000/XP.)

            If (Not (hidHandle.IsInvalid)) Then

                ' Don't attempt to send an Output report if the HID has no Output report.

                If (MyHid.Capabilities.OutputReportByteLength > 0) Then

                    ' Set the upper bound of the Output report buffer. 
                    ' Subtract 1 from OutputReportByteLength because the array begins at index 0.

                    ' Make sure buffer is the right size. (Should be 9 for the Finch)
                    Array.Resize(outputReportBuffer, MyHid.Capabilities.OutputReportByteLength)

                    ' Write a report.
                    If (fileStreamdevicedata.CanWrite) Then
                        fileStreamdevicedata.Write(outputReportBuffer, 0, outputReportBuffer.Length)
                        success = True
                    Else
                        CloseCommunications()
                        writeToLog("The attempt to read an Input report has failed.")
                    End If


                    If success Then

                        writeToLog("An Output report has been written.")

                        ' Display the report data

                        writeToLog(" Output Report ID: " & String.Format("{0:X2} ", outputReportBuffer(0)))
                        writeToLog(" Output Report Data:")

                        For count = 1 To UBound(outputReportBuffer)

                            ' Display bytes as 2-character hex strings.

                            byteValue = String.Format("{0:X2} ", outputReportBuffer(count))
                            writeToLog(" " & byteValue)

                        Next count
                    Else
                        CloseCommunications()
                        writeToLog("The attempt to write an Output report failed.")
                    End If


                Else
                    writeToLog("The HID doesn't have an Output report.")
                End If

                ' Read an Input report.

                success = False

                ' Don't attempt to send an Input report if the HID has no Input report.
                ' (The HID spec requires all HIDs to have an interrupt IN endpoint,
                ' which suggests that all HIDs must support Input reports.)

                If (MyHid.Capabilities.InputReportByteLength > 0 And hasReply) Then

                    ' Set the size of the Input report buffer. 
                    Array.Resize(inputReportBuffer, MyHid.Capabilities.InputReportByteLength)

                    ' Read a report using interrupt transfers.                
                    ' To enable reading a report without blocking the main thread, this
                    ' application uses an asynchronous delegate.

                    'Dim ar As IAsyncResult = Nothing
                    transferInProgress = True

                    ' Timeout if no report is available.

                    tmrReadTimeout.Start()

                    If (fileStreamdevicedata.CanRead) Then

                        fileStreamdevicedata.BeginRead(inputReportBuffer, 0, inputReportBuffer.Length, New AsyncCallback(AddressOf GetInputReportData), inputReportBuffer)

                        ' Wait for input report to arrive
                        While (inputReportBuffer(UBound(inputReportBuffer)) = 0)
                        End While
                    Else
                        CloseCommunications()
                        writeToLog("The attempt to read an Input report has failed.")
                    End If
                Else

                    writeToLog("No attempt to read an Input report was made.")
                    writeToLog("The HID doesn't have an Input report.")
                End If
            Else
                writeToLog("Invalid handle. The device is probably a system mouse or keyboard.")
                writeToLog("No attempt to write an Output report or read an Input report was made.")
            End If

        Catch ex As Exception
            DisplayException("FinchMain", ex)
            Throw
        End Try

        Return inputReportBuffer

    End Function

    ''' <summary>
    ''' Close the handle and FileStreams for a device.
    ''' </summary>

    Private Sub CloseCommunications()

        If (Not (fileStreamdevicedata Is Nothing)) Then

            fileStreamdevicedata.Close()
        End If

        If (Not (hidHandle Is Nothing)) Then
            If (Not (hidHandle.IsInvalid)) Then
                hidHandle.Close()
            End If
        End If

        ' The next attempt to communicate will get new handles and FileStreams.

        myDeviceDetected = False


    End Sub

    ''' <summary>
    ''' Retrieves Input report data and status information.
    ''' This routine is called automatically when myInputReport.Read
    ''' returns. Calls several marshaling routines to access the main form.
    ''' </summary>
    ''' 
    ''' <param name="ar"> an object containing status information about 
    ''' the asynchronous operation. </param>

    Private Sub GetInputReportData(ByVal ar As IAsyncResult)

        Dim byteValue As String
        Dim count As Int32
        Dim inputReportBuffer As Byte() = Nothing

        writeToLog("GetInputReportData has been called.")

        Try
            ' Convert to byte array and store in buffer
            inputReportBuffer = CType(ar.AsyncState, Byte())

            fileStreamdevicedata.EndRead(ar)
            writeToLog("Reading complete!")

            tmrReadTimeout.Stop()

            ' Display the received report data in the form's list box.

            If (ar.IsCompleted) Then

                writeToLog("An Input report has been read.")

                writeToLog(" Input Report ID: " & String.Format("{0:X2} ", inputReportBuffer(0)))

                writeToLog(" Input Report Data:")

                For count = 1 To UBound(inputReportBuffer)

                    ' Display bytes as 2-character Hex strings.

                    byteValue = String.Format("{0:X2} ", inputReportBuffer(count))

                    writeToLog(" " & byteValue)

                Next count

            Else
                writeToLog("The attempt to read an Input report has failed.")
            End If

            ' Enable requesting another transfer.

            transferInProgress = False

        Catch ex As Exception
            DisplayException("FinchMain", ex)
            Throw
        End Try

    End Sub

    ''' <summary>
    ''' Initiates exchanging reports. 
    ''' The application sends a report and requests to read a report.
    ''' </summary>
    ''' 
    ''' <param name="outputBuffer"> Output to be sent to the Finch </param>
    ''' <param name="hasReply"> True if the input is expected to generate a reply </param>
    ''' 
    ''' <returns> Input buffer </returns>

    Friend Function ReadAndWriteToDevice(ByVal outputBuffer() As Byte, ByVal hasReply As Boolean) As Byte()
        'Report header for the debug display:

        writeToLog("")
        writeToLog("***** HID Test Report *****")
        writeToLog(Today & ": " & TimeOfDay)

        Try
            ' If the device hasn't been detected, was removed, or timed out on a previous attempt
            ' to access it, look for the device.

            If (myDeviceDetected = False) Then

                myDeviceDetected = FindTheHid()

            End If

            If (myDeviceDetected = True) Then
                Return ExchangeInputAndOutputReports(outputBuffer, hasReply)

            End If

        Catch ex As Exception
            DisplayException("FinchMain", ex)
            Throw
        End Try

        Return Nothing
    End Function

    ''' <summary>
    ''' System timer timeout if read via interrupt transfer doesn't return.
    ''' </summary>
    ''' <param name="source"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>

    Private Sub OnReadTimeout(ByVal source As Object, ByVal e As ElapsedEventArgs)
        CloseCommunications()

        tmrReadTimeout.Stop()

    End Sub

    ''' <summary>
    ''' Provides a central mechanism for exception handling.
    ''' Displays a message box that describes the exception.
    ''' </summary>
    ''' 
    ''' <param name="moduleName"> the module where the exception occurred. </param>
    ''' <param name="e"> the exception </param>

    Shared Sub DisplayException(ByVal moduleName As String, ByVal e As Exception)

        Dim message As String
        Dim caption As String

        ' Create an error message.

        message = "Exception: " & e.Message & ControlChars.CrLf & _
        "Module: " & moduleName & ControlChars.CrLf & _
        "Method: " & e.TargetSite.Name

        caption = "Unexpected Exception"

        MessageBox.Show(message, caption, MessageBoxButtons.OK)
        writeToLog(message)

    End Sub

    Shared Sub createLogFile()
        Try
            My.Computer.FileSystem.WriteAllText(logFile, "", False)
        Catch e As Exception
            DisplayException("FinchHID", e)
        End Try
    End Sub

    ''' <summary>
    ''' Write to Finch log file.
    ''' If the file can't be opened, text is saved to a buffer and 
    ''' written to the file next time. 
    ''' </summary>
    ''' <param name="text">Text to write to file.</param>
    Shared Sub writeToLog(ByVal text As String)
        text = "[" & DateTime.Now & "] " & text & vbCrLf
        Try
            logBuffer = String.Concat(logBuffer, text)
            My.Computer.FileSystem.WriteAllText(logFile, logBuffer, True)
            logBuffer = ""
        Catch e As System.IO.IOException
            logBuffer = String.Concat(logBuffer, text)
        End Try

    End Sub
End Class
