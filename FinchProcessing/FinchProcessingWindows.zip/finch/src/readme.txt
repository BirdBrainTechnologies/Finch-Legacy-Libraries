You can always check out the latest source of the Finch package at:
http://code.google.com/p/finch-robot/